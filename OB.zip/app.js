// FarmDirect Application JavaScript
class FarmDirectApp {
    constructor() {
        this.currentLanguage = 'en';
        this.cart = [];
        this.currentUser = null;
        this.isVoiceActive = false;
        this.chatbotExpanded = true;
        this.selectedPaymentMethod = null;
        
        // Application data
        this.data = {
            "languages": {
                "en": "English",
                "ta": "தமிழ்",
                "hi": "हिन्दी"
            },
            "categories": [
                {"id": 1, "name": "Vegetables", "name_ta": "காய்கறிகள்", "name_hi": "सब्जियाँ", "icon": "🥕"},
                {"id": 2, "name": "Fruits", "name_ta": "பழங்கள்", "name_hi": "फल", "icon": "🍎"},
                {"id": 3, "name": "Grains", "name_ta": "தானியங்கள்", "name_hi": "अनाज", "icon": "🌾"},
                {"id": 4, "name": "Dairy", "name_ta": "பால் பொருட்கள்", "name_hi": "डेयरी", "icon": "🥛"},
                {"id": 5, "name": "Spices", "name_ta": "மசாலாப் பொருட்கள்", "name_hi": "मसाले", "icon": "🌶️"}
            ],
            "products": [
                {
                    "id": 1,
                    "name": "Fresh Tomatoes",
                    "name_ta": "புதிய தக்காளி",
                    "name_hi": "ताजा टमाटर",
                    "farmer": "Ravi Kumar",
                    "farmer_ta": "ரவி குமார்",
                    "price": 40,
                    "unit": "per kg",
                    "unit_ta": "கிலோ விலை",
                    "category": 1,
                    "location": "Coimbatore, Tamil Nadu",
                    "location_ta": "கோயம்புத்தூர், தமிழ்நாடு",
                    "rating": 4.8,
                    "image": "https://images.unsplash.com/photo-1546470427-e9460d2d9c56?w=300&h=200&fit=crop",
                    "description": "Fresh, organic tomatoes grown without pesticides",
                    "description_ta": "பூச்சிக்கொல்லி இல்லாமல் வளர்க்கப்பட்ட புதிய, இயற்கை தக்காளி",
                    "benefits": "Rich in Vitamin C and Lycopene"
                },
                {
                    "id": 2,
                    "name": "Basmati Rice",
                    "name_ta": "பாஸ்மதி அரிசி",
                    "name_hi": "बासमती चावल",
                    "farmer": "Sunita Devi",
                    "farmer_ta": "சுனிதா தேவி",
                    "price": 120,
                    "unit": "per kg",
                    "unit_ta": "கிலோ விலை",
                    "category": 3,
                    "location": "Salem, Tamil Nadu",
                    "location_ta": "சேலம், தமிழ்நாடு",
                    "rating": 4.9,
                    "image": "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=300&h=200&fit=crop",
                    "description": "Premium quality basmati rice",
                    "description_ta": "உயர்ந்த தரமான பாஸ்மதி அரிசி",
                    "benefits": "Low glycemic index, rich in fiber"
                },
                {
                    "id": 3,
                    "name": "Fresh Carrots",
                    "name_ta": "புதிய கேரட்",
                    "name_hi": "ताजा गाजर",
                    "farmer": "Muthu Swamy",
                    "farmer_ta": "முத்து சாமி",
                    "price": 35,
                    "unit": "per kg",
                    "unit_ta": "கிலோ விலை",
                    "category": 1,
                    "location": "Madurai, Tamil Nadu",
                    "location_ta": "மதுரை, தமிழ்நாடு",
                    "rating": 4.6,
                    "image": "https://images.unsplash.com/photo-1445282768818-728615cc910a?w=300&h=200&fit=crop",
                    "description": "Sweet and crunchy organic carrots",
                    "description_ta": "இனிப்பான மற்றும் மொறுமொறுப்பான இயற்கை கேரட்",
                    "benefits": "High in Vitamin A and antioxidants"
                },
                {
                    "id": 4,
                    "name": "Fresh Spinach",
                    "name_ta": "புதிய கீரை",
                    "name_hi": "ताजा पालक",
                    "farmer": "Lakshmi Devi",
                    "farmer_ta": "லக்ஷ்மி தேவி",
                    "price": 25,
                    "unit": "per kg",
                    "unit_ta": "கிலோ விலை",
                    "category": 1,
                    "location": "Trichy, Tamil Nadu",
                    "location_ta": "திருச்சி, தமிழ்நாடு",
                    "rating": 4.7,
                    "image": "https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=300&h=200&fit=crop",
                    "description": "Fresh leafy green spinach",
                    "description_ta": "புதிய இலைக்கீரை",
                    "benefits": "High in iron and vitamins"
                },
                {
                    "id": 5,
                    "name": "Organic Mangoes",
                    "name_ta": "இயற்கை மாம்பழம்",
                    "name_hi": "जैविक आम",
                    "farmer": "Krishna Farmer",
                    "farmer_ta": "கிருஷ்ணா விவசாயி",
                    "price": 80,
                    "unit": "per kg",
                    "unit_ta": "கிலோ விலை",
                    "category": 2,
                    "location": "Thanjavur, Tamil Nadu",
                    "location_ta": "தஞ்சாவூர், தமிழ்நாடு",
                    "rating": 4.9,
                    "image": "https://images.unsplash.com/photo-1605552055715-6272a870fb6e?w=300&h=200&fit=crop",
                    "description": "Sweet and juicy organic mangoes",
                    "description_ta": "இனிப்பான மற்றும் சுவையான இயற்கை மாம்பழம்",
                    "benefits": "Rich in Vitamin C and fiber"
                }
            ],
            "farmers": [
                {
                    "id": 1,
                    "name": "Ravi Kumar",
                    "name_ta": "ரவி குமார்",
                    "location": "Coimbatore",
                    "location_ta": "கோயம்புத்தூர்",
                    "lat": 11.0168,
                    "lng": 76.9558,
                    "rating": 4.8,
                    "products_count": 15,
                    "speciality": "Organic Vegetables",
                    "speciality_ta": "இயற்கை காய்கறிகள்",
                    "phone": "+91 98765 43210"
                },
                {
                    "id": 2,
                    "name": "Sunita Devi",
                    "name_ta": "சுனிதா தேவி",
                    "location": "Salem",
                    "location_ta": "சேலம்",
                    "lat": 11.6643,
                    "lng": 78.1460,
                    "rating": 4.9,
                    "products_count": 8,
                    "speciality": "Rice & Grains",
                    "speciality_ta": "அரிசி மற்றும் தானியங்கள்",
                    "phone": "+91 98765 43211"
                }
            ],
            "storage_spaces": [
                {
                    "id": 1,
                    "title": "Climate Controlled Warehouse",
                    "title_ta": "வெப்பநிலை கட்டுப்பாட்டு கிடங்கு",
                    "location": "Chennai, Tamil Nadu",
                    "location_ta": "சென்னை, தமிழ்நாடு",
                    "lat": 13.0827,
                    "lng": 80.2707,
                    "area": "500 sq ft",
                    "price": 5000,
                    "unit": "per month",
                    "unit_ta": "மாதத்திற்கு",
                    "owner": "Rajesh Storage Solutions",
                    "owner_ta": "ராஜேஷ் சேமிப்பு தீர்வுகள்",
                    "contact": "+91 99999 88888",
                    "features": ["Climate Control", "24/7 Security", "Easy Access"]
                },
                {
                    "id": 2,
                    "title": "Cold Storage Facility",
                    "title_ta": "குளிர்பதன சேமிப்பு வசதி",
                    "location": "Coimbatore, Tamil Nadu",
                    "location_ta": "கோயம்புத்தூர், தமிழ்நாடு",
                    "lat": 11.0168,
                    "lng": 76.9558,
                    "area": "1000 sq ft",
                    "price": 8000,
                    "unit": "per month",
                    "unit_ta": "மாதத்திற்கு",
                    "owner": "Fresh Storage Co.",
                    "owner_ta": "புதிய சேமிப்பு நிறுவனம்",
                    "contact": "+91 88888 77777",
                    "features": ["Refrigeration", "Pest Control", "Loading Dock"]
                }
            ],
            "weather": {
                "location": "Tamil Nadu",
                "location_ta": "தமிழ்நாடு",
                "temperature": 28,
                "condition": "Partly Cloudy",
                "condition_ta": "பகுதியளவு மேகமூட்டம்",
                "humidity": 65,
                "rainfall": "Light rain expected",
                "rainfall_ta": "லேசான மழை எதிர்பார்க்கப்படுகிறது",
                "forecast": [
                    {"day": "Today", "day_ta": "இன்று", "temp": 28, "condition": "Partly Cloudy"},
                    {"day": "Tomorrow", "day_ta": "நாளை", "temp": 30, "condition": "Sunny"},
                    {"day": "Day After", "day_ta": "அதற்கு அடுத்த நாள்", "temp": 27, "condition": "Rainy"}
                ]
            },
            "chat_responses": [
                {
                    "trigger": "hello",
                    "response": "Hello! Welcome to our farmer marketplace. How can I help you today?",
                    "response_ta": "வணக்கம்! எங்கள் விவசாயி சந்தைக்கு வரவேற்கிறோம். இன்று நான் உங்களுக்கு எப்படி உதவ முடியும்?"
                },
                {
                    "trigger": "products",
                    "response": "We have fresh vegetables, fruits, grains, dairy products and spices available. What are you looking for?",
                    "response_ta": "எங்களிடம் புதிய காய்கறிகள், பழங்கள், தானியங்கள், பால் பொருட்கள் மற்றும் மசாலாப் பொருட்கள் உள்ளன. நீங்கள் என்ன தேடுகிறீர்கள்?"
                },
                {
                    "trigger": "payment",
                    "response": "We accept UPI payments through GPay, PhonePe, Paytm and also offer Buy Now Pay Later options for retailers.",
                    "response_ta": "நாங்கள் GPay, PhonePe, Paytm மூலம் UPI பேமெண்ட்களை ஏற்கிறோம் மற்றும் சில்லறை விற்பனையாளர்களுக்கு இப்போது வாங்கி பின்னர் பணம் செலுத்தும் வசதியும் வழங்குகிறோம்."
                }
            ],
            "payment_methods": [
                {"name": "GPay", "logo": "🟢", "type": "UPI"},
                {"name": "PhonePe", "logo": "🟣", "type": "UPI"},
                {"name": "Paytm", "logo": "🔵", "type": "UPI"},
                {"name": "BNPL", "logo": "💳", "type": "Credit"}
            ]
        };

        // Translations
        this.translations = {
            en: {
                app_name: "FarmDirect",
                nav_home: "Home",
                nav_products: "Products",
                nav_farmers: "Farmers",
                nav_storage: "Storage",
                nav_weather: "Weather",
                login: "Login",
                register: "Register",
                hero_title: "Direct Market Access to Farmers",
                hero_subtitle: "Connect directly with farmers, get fresh produce, and support local agriculture",
                search_placeholder: "Search for products...",
                search: "Search",
                find_nearby: "Find Nearby Farmers",
                categories_title: "Shop by Category",
                weather_title: "Weather Information",
                products_title: "Fresh Products",
                farmers_map_title: "Find Farmers Near You",
                storage_title: "Storage Rental Marketplace",
                cart_title: "Shopping Cart",
                total: "Total",
                checkout: "Checkout",
                ai_assistant: "AI Assistant",
                welcome_message: "Hello! How can I help you today?",
                chat_placeholder: "Type your message...",
                all_categories: "All Categories",
                sort_rating: "Sort by Rating",
                sort_price_low: "Price: Low to High",
                sort_price_high: "Price: High to Low",
                show_all_farmers: "Show All Farmers",
                list_storage: "List Your Storage Space",
                find_storage: "Find Storage Space",
                login_title: "Login to Your Account",
                register_title: "Create Account",
                checkout_title: "Checkout",
                email: "Email",
                password: "Password",
                user_type: "User Type",
                customer: "Customer",
                farmer: "Farmer",
                retailer: "Retailer",
                name: "Full Name",
                phone: "Phone Number",
                location: "Location",
                payment_methods: "Payment Methods",
                delivery_info: "Delivery Information",
                delivery_address: "Delivery Address",
                place_order: "Place Order",
                add_to_cart: "Add to Cart",
                buy_now: "Buy Now"
            },
            ta: {
                app_name: "விவசாய நேரடி",
                nav_home: "முகப்பு",
                nav_products: "பொருட்கள்",
                nav_farmers: "விவசாயிகள்",
                nav_storage: "சேமிப்பு",
                nav_weather: "வானிலை",
                login: "உள்நுழைய",
                register: "பதிவு செய்க",
                hero_title: "விவசாயிகளுக்கு நேரடி சந்தை அணுகல்",
                hero_subtitle: "விவசாயிகளுடன் நேரடியாக இணைந்து, புதிய பொருட்களைப் பெறுங்கள்",
                search_placeholder: "பொருட்களைத் தேடுங்கள்...",
                search: "தேடு",
                find_nearby: "அருகிலுள்ள விவசாயிகளைக் கண்டறியுங்கள்",
                categories_title: "வகையால் ஷாப் செய்யுங்கள்",
                weather_title: "வானிலை தகவல்",
                products_title: "புதிய பொருட்கள்",
                farmers_map_title: "உங்களுக்கு அருகில் உள்ள விவசாயிகளைக் கண்டறியுங்கள்",
                storage_title: "சேமிப்பு வாடகை சந்தை",
                cart_title: "வாங்குதல் கூடை",
                total: "மொத்தம்",
                checkout: "செக்அவுட்",
                ai_assistant: "ஏஐ உதவியாளர்",
                welcome_message: "வணக்கம்! இன்று நான் உங்களுக்கு எப்படி உதவ முடியும்?",
                chat_placeholder: "உங்கள் செய்தியை தட்டச்சு செய்யுங்கள்...",
                all_categories: "எல்லா வகைகளும்",
                sort_rating: "மதிப்பீட்டின் அடிப்படையில் வரிசைப்படுத்து",
                sort_price_low: "விலை: குறைவானது முதல் அதிகமானது வரை",
                sort_price_high: "விலை: அதிகமானது முதல் குறைவானது வரை",
                show_all_farmers: "அனைத்து விவசாயிகளையும் காட்டு",
                list_storage: "உங்கள் சேமிப்பு இடத்தை பட்டியலிடுங்கள்",
                find_storage: "சேமிப்பு இடத்தைக் கண்டறியுங்கள்",
                login_title: "உங்கள் கணக்கில் உள்நுழையுங்கள்",
                register_title: "கணக்கை உருவாக்கவும்",
                checkout_title: "செக்அவுட்",
                email: "மின்னஞ்சல்",
                password: "கடவுச்சொல்",
                user_type: "பயனர் வகை",
                customer: "வாடிக்கையாளர்",
                farmer: "விவசாயி",
                retailer: "சில்லறை விற்பனையாளர்",
                name: "முழு பெயர்",
                phone: "தொலைபேசி எண்",
                location: "இடம்",
                payment_methods: "பணம் செலுத்தும் முறைகள்",
                delivery_info: "விநியோக தகவல்",
                delivery_address: "விநியோக முகவரி",
                place_order: "ஆர்டர் வைக்கவும்",
                add_to_cart: "கூடையில் சேர்க்கவும்",
                buy_now: "இப்போது வாங்கவும்"
            }
        };

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadCategories();
        this.loadProducts();
        this.loadFarmers();
        this.loadStorage();
        this.loadWeather();
        this.loadPaymentMethods();
        this.updateLanguage();
        this.initVoiceRecognition();
        this.initChatbot();
        this.updateCartDisplay();
        this.showFloatingCartButton(); // Ensure cart button is visible
    }

    setupEventListeners() {
        // Language switcher
        const languageSelect = document.getElementById('languageSelect');
        if (languageSelect) {
            languageSelect.addEventListener('change', (e) => {
                this.currentLanguage = e.target.value;
                this.updateLanguage();
                this.updateChatbotLanguage(); // Update chatbot language
            });
        }

        // Navigation - smooth scroll to sections
        document.querySelectorAll('.nav a').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    // Update active nav link
                    document.querySelectorAll('.nav a').forEach(a => a.classList.remove('active'));
                    link.classList.add('active');
                }
            });
        });

        // Voice button
        const voiceBtn = document.getElementById('voiceBtn');
        if (voiceBtn) {
            voiceBtn.addEventListener('click', () => {
                this.toggleVoiceRecognition();
            });
        }

        // Search functionality
        const searchBtn = document.getElementById('searchBtn');
        const searchInput = document.getElementById('searchInput');
        
        if (searchBtn) {
            searchBtn.addEventListener('click', () => {
                this.performSearch();
            });
        }

        if (searchInput) {
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.performSearch();
                }
            });
        }

        // Location button
        const locationBtn = document.getElementById('locationBtn');
        if (locationBtn) {
            locationBtn.addEventListener('click', () => {
                this.findNearbyFarmers();
            });
        }

        // Modal controls
        this.setupModalControls();

        // Cart controls
        this.setupCartControls();

        // Product filters
        const categoryFilter = document.getElementById('categoryFilter');
        const sortFilter = document.getElementById('sortFilter');
        
        if (categoryFilter) {
            categoryFilter.addEventListener('change', () => {
                this.filterProducts();
            });
        }

        if (sortFilter) {
            sortFilter.addEventListener('change', () => {
                this.sortProducts();
            });
        }

        // Storage controls
        const listStorageBtn = document.getElementById('listStorageBtn');
        const findStorageBtn = document.getElementById('findStorageBtn');
        
        if (listStorageBtn) {
            listStorageBtn.addEventListener('click', () => {
                this.showToast('Storage listing form would open here', 'info');
            });
        }

        if (findStorageBtn) {
            findStorageBtn.addEventListener('click', () => {
                this.showToast('Finding available storage spaces...', 'info');
            });
        }

        // Farmers map
        const showAllFarmersBtn = document.getElementById('showAllFarmers');
        if (showAllFarmersBtn) {
            showAllFarmersBtn.addEventListener('click', () => {
                this.showAllFarmers();
            });
        }

        // Chatbot
        this.setupChatbot();

        // Keyboard event listeners for modals
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });

        // Click outside modal to close
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal-backdrop')) {
                const modal = e.target.closest('.modal');
                if (modal) {
                    modal.classList.remove('show');
                }
            }
        });
    }

    setupModalControls() {
        // Login modal
        const loginBtn = document.getElementById('loginBtn');
        const closeLoginModal = document.getElementById('closeLoginModal');
        const loginBackdrop = document.getElementById('loginBackdrop');

        if (loginBtn) {
            loginBtn.addEventListener('click', () => {
                this.showModal('loginModal');
            });
        }

        if (closeLoginModal) {
            closeLoginModal.addEventListener('click', () => {
                this.hideModal('loginModal');
            });
        }

        if (loginBackdrop) {
            loginBackdrop.addEventListener('click', () => {
                this.hideModal('loginModal');
            });
        }

        // Register modal
        const registerBtn = document.getElementById('registerBtn');
        const closeRegisterModal = document.getElementById('closeRegisterModal');
        const registerBackdrop = document.getElementById('registerBackdrop');

        if (registerBtn) {
            registerBtn.addEventListener('click', () => {
                this.showModal('registerModal');
            });
        }

        if (closeRegisterModal) {
            closeRegisterModal.addEventListener('click', () => {
                this.hideModal('registerModal');
            });
        }

        if (registerBackdrop) {
            registerBackdrop.addEventListener('click', () => {
                this.hideModal('registerModal');
            });
        }

        // Checkout modal
        const closeCheckoutModal = document.getElementById('closeCheckoutModal');
        const checkoutBackdrop = document.getElementById('checkoutBackdrop');

        if (closeCheckoutModal) {
            closeCheckoutModal.addEventListener('click', () => {
                this.hideModal('checkoutModal');
            });
        }

        if (checkoutBackdrop) {
            checkoutBackdrop.addEventListener('click', () => {
                this.hideModal('checkoutModal');
            });
        }

        // Form submissions
        const loginForm = document.querySelector('.login-form');
        const registerForm = document.querySelector('.register-form');
        const placeOrderBtn = document.getElementById('placeOrderBtn');

        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin();
            });
        }

        if (registerForm) {
            registerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleRegister();
            });
        }

        if (placeOrderBtn) {
            placeOrderBtn.addEventListener('click', () => {
                this.placeOrder();
            });
        }
    }

    setupCartControls() {
        const floatingCartBtn = document.getElementById('floatingCartBtn');
        const closeCartBtn = document.getElementById('closeCartBtn');
        const checkoutBtn = document.getElementById('checkoutBtn');

        if (floatingCartBtn) {
            floatingCartBtn.addEventListener('click', () => {
                this.toggleCart();
            });
        }

        if (closeCartBtn) {
            closeCartBtn.addEventListener('click', () => {
                this.toggleCart();
            });
        }

        if (checkoutBtn) {
            checkoutBtn.addEventListener('click', () => {
                this.proceedToCheckout();
            });
        }
    }

    setupChatbot() {
        const chatbotHeader = document.getElementById('chatbotHeader');
        const chatbotToggle = document.getElementById('chatbotToggle');
        const chatSendBtn = document.getElementById('chatSendBtn');
        const chatInput = document.getElementById('chatInput');
        const chatVoiceBtn = document.getElementById('chatVoiceBtn');

        if (chatbotHeader) {
            chatbotHeader.addEventListener('click', () => {
                this.toggleChatbot();
            });
        }

        if (chatbotToggle) {
            chatbotToggle.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleChatbot();
            });
        }

        if (chatSendBtn) {
            chatSendBtn.addEventListener('click', () => {
                this.sendChatMessage();
            });
        }

        if (chatInput) {
            chatInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.sendChatMessage();
                }
            });
        }

        if (chatVoiceBtn) {
            chatVoiceBtn.addEventListener('click', () => {
                this.startChatVoiceInput();
            });
        }
    }

    loadCategories() {
        const grid = document.getElementById('categoriesGrid');
        const categoryFilter = document.getElementById('categoryFilter');
        
        if (!grid) return;
        
        grid.innerHTML = '';
        
        if (categoryFilter) {
            // Clear existing options except the first one
            while (categoryFilter.children.length > 1) {
                categoryFilter.removeChild(categoryFilter.lastChild);
            }
        }
        
        this.data.categories.forEach(category => {
            const card = document.createElement('div');
            card.className = 'category-card';
            card.innerHTML = `
                <div class="icon">${category.icon}</div>
                <h3>${this.getTranslatedText(category, 'name')}</h3>
            `;
            card.addEventListener('click', () => {
                this.filterByCategory(category.id);
            });
            grid.appendChild(card);

            // Add to filter dropdown
            if (categoryFilter) {
                const option = document.createElement('option');
                option.value = category.id;
                option.textContent = this.getTranslatedText(category, 'name');
                categoryFilter.appendChild(option);
            }
        });
    }

    loadProducts() {
        const grid = document.getElementById('productsGrid');
        if (!grid) return;
        
        grid.innerHTML = '';

        this.data.products.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
            card.dataset.category = product.category;
            card.innerHTML = `
                <div class="product-image" style="background-image: url('${product.image}')">
                    <div class="product-badge">★ ${product.rating}</div>
                </div>
                <div class="product-info">
                    <h3 class="product-title">${this.getTranslatedText(product, 'name')}</h3>
                    <p class="product-farmer">${this.getTranslatedText(product, 'farmer')}</p>
                    <div class="product-price">₹${product.price} ${this.getTranslatedText(product, 'unit')}</div>
                    <div class="product-rating">
                        <span class="stars">${this.generateStars(product.rating)}</span>
                        <span>(${product.rating})</span>
                    </div>
                    <div class="product-actions">
                        <button class="add-to-cart-btn" onclick="app.addToCart(${product.id})">
                            ${this.translate('add_to_cart')}
                        </button>
                    </div>
                </div>
            `;
            grid.appendChild(card);
        });
    }

    loadFarmers() {
        const list = document.getElementById('farmersList');
        if (!list) return;
        
        list.innerHTML = '';

        this.data.farmers.forEach(farmer => {
            const card = document.createElement('div');
            card.className = 'farmer-card';
            card.innerHTML = `
                <div class="farmer-info">
                    <div class="farmer-name">${this.getTranslatedText(farmer, 'name')}</div>
                    <div class="farmer-location">📍 ${this.getTranslatedText(farmer, 'location')}</div>
                    <div class="farmer-speciality">${this.getTranslatedText(farmer, 'speciality')}</div>
                </div>
                <div class="farmer-stats">
                    <span>★ ${farmer.rating}</span>
                    <span>${farmer.products_count} products</span>
                </div>
            `;
            card.addEventListener('click', () => {
                this.showFarmerDetails(farmer);
            });
            list.appendChild(card);
        });
    }

    loadStorage() {
        const grid = document.getElementById('storageGrid');
        if (!grid) return;
        
        grid.innerHTML = '';

        this.data.storage_spaces.forEach(space => {
            const card = document.createElement('div');
            card.className = 'storage-card';
            card.innerHTML = `
                <h3 class="storage-title">${this.getTranslatedText(space, 'title')}</h3>
                <div class="storage-price">₹${space.price} ${this.getTranslatedText(space, 'unit')}</div>
                <p>📍 ${this.getTranslatedText(space, 'location')}</p>
                <p>📏 ${space.area}</p>
                <ul class="storage-features">
                    ${space.features.map(feature => `<li>${feature}</li>`).join('')}
                </ul>
                <button class="btn btn--primary" onclick="app.contactStorageOwner('${space.contact}')">
                    Contact Owner
                </button>
            `;
            grid.appendChild(card);
        });
    }

    loadWeather() {
        const content = document.getElementById('weatherContent');
        if (!content) return;
        
        const weather = this.data.weather;
        
        content.innerHTML = `
            <div class="weather-current">
                <div class="temp">${weather.temperature}°C</div>
                <div>${this.getTranslatedText(weather, 'condition')}</div>
                <div>💧 ${weather.humidity}% humidity</div>
                <div>🌧️ ${this.getTranslatedText(weather, 'rainfall')}</div>
            </div>
            <div class="weather-forecast">
                ${weather.forecast.map(day => `
                    <div class="forecast-item">
                        <div>${this.getTranslatedText(day, 'day')}</div>
                        <div>${day.temp}°C</div>
                        <div>${day.condition}</div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    loadPaymentMethods() {
        const container = document.getElementById('paymentOptions');
        if (!container) return;
        
        container.innerHTML = '';

        this.data.payment_methods.forEach(method => {
            const option = document.createElement('div');
            option.className = 'payment-option';
            option.innerHTML = `
                <div class="logo">${method.logo}</div>
                <div>${method.name}</div>
            `;
            option.addEventListener('click', () => {
                this.selectPaymentMethod(method, option);
            });
            container.appendChild(option);
        });
    }

    // Utility functions
    getTranslatedText(object, field) {
        const translatedField = `${field}_${this.currentLanguage}`;
        return object[translatedField] || object[field];
    }

    translate(key) {
        return this.translations[this.currentLanguage][key] || this.translations.en[key];
    }

    updateLanguage() {
        document.querySelectorAll('[data-translate]').forEach(element => {
            const key = element.getAttribute('data-translate');
            element.textContent = this.translate(key);
        });

        document.querySelectorAll('[data-translate-placeholder]').forEach(element => {
            const key = element.getAttribute('data-translate-placeholder');
            element.placeholder = this.translate(key);
        });

        // Apply Tamil font class if needed
        if (this.currentLanguage === 'ta') {
            document.body.classList.add('tamil-text');
        } else {
            document.body.classList.remove('tamil-text');
        }

        // Reload dynamic content
        this.loadCategories();
        this.loadProducts();
        this.loadFarmers();
        this.loadStorage();
        this.loadWeather();
    }

    updateChatbotLanguage() {
        // Clear existing messages and add new welcome message
        const messages = document.getElementById('chatMessages');
        if (messages) {
            messages.innerHTML = '';
            this.addChatMessage('bot', this.translate('welcome_message'));
        }
    }

    generateStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 !== 0;
        let stars = '';
        
        for (let i = 0; i < fullStars; i++) {
            stars += '★';
        }
        
        if (hasHalfStar) {
            stars += '☆';
        }
        
        return stars;
    }

    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
        }
    }

    hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
        }
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.remove('show');
        });
    }

    showToast(message, type = 'success') {
        const toast = document.getElementById('toast');
        const toastMessage = document.getElementById('toastMessage');
        
        if (!toast || !toastMessage) return;
        
        toastMessage.textContent = message;
        toast.className = `toast ${type} show`;
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    showSpinner() {
        const spinner = document.getElementById('loadingSpinner');
        if (spinner) {
            spinner.classList.add('show');
        }
    }

    hideSpinner() {
        const spinner = document.getElementById('loadingSpinner');
        if (spinner) {
            spinner.classList.remove('show');
        }
    }

    showFloatingCartButton() {
        const floatingCartBtn = document.getElementById('floatingCartBtn');
        if (floatingCartBtn) {
            floatingCartBtn.style.display = 'flex';
        }
    }

    // Cart functionality
    addToCart(productId) {
        const product = this.data.products.find(p => p.id === productId);
        if (product) {
            const existingItem = this.cart.find(item => item.id === productId);
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                this.cart.push({ ...product, quantity: 1 });
            }
            this.updateCartDisplay();
            this.showFloatingCartButton(); // Ensure button is visible
            this.showToast(`${this.getTranslatedText(product, 'name')} added to cart!`);
        }
    }

    updateCartDisplay() {
        const cartItems = document.getElementById('cartItems');
        const cartCount = document.getElementById('cartCount');
        const cartTotal = document.getElementById('cartTotal');
        
        if (!cartItems || !cartCount || !cartTotal) return;
        
        cartItems.innerHTML = '';
        let total = 0;
        let itemCount = 0;

        this.cart.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.className = 'cart-item';
            itemElement.innerHTML = `
                <div class="cart-item-image" style="background-image: url('${item.image}')"></div>
                <div class="cart-item-info">
                    <div class="cart-item-name">${this.getTranslatedText(item, 'name')}</div>
                    <div class="cart-item-price">₹${item.price}</div>
                </div>
                <div class="cart-item-controls">
                    <button class="quantity-btn" onclick="app.updateQuantity(${item.id}, -1)">-</button>
                    <span>${item.quantity}</span>
                    <button class="quantity-btn" onclick="app.updateQuantity(${item.id}, 1)">+</button>
                </div>
            `;
            cartItems.appendChild(itemElement);
            
            total += item.price * item.quantity;
            itemCount += item.quantity;
        });

        cartCount.textContent = itemCount;
        cartTotal.textContent = total;

        // Show/hide cart button based on cart content
        const floatingCartBtn = document.getElementById('floatingCartBtn');
        if (floatingCartBtn) {
            if (itemCount > 0) {
                floatingCartBtn.style.display = 'flex';
            } else {
                floatingCartBtn.style.display = 'none';
            }
        }
    }

    updateQuantity(productId, change) {
        const item = this.cart.find(item => item.id === productId);
        if (item) {
            item.quantity += change;
            if (item.quantity <= 0) {
                this.cart = this.cart.filter(cartItem => cartItem.id !== productId);
            }
            this.updateCartDisplay();
        }
    }

    toggleCart() {
        const cartSidebar = document.getElementById('cartSidebar');
        if (cartSidebar) {
            cartSidebar.classList.toggle('open');
        }
    }

    proceedToCheckout() {
        if (this.cart.length === 0) {
            this.showToast('Your cart is empty!', 'warning');
            return;
        }
        
        this.updateOrderSummary();
        this.toggleCart(); // Close cart
        this.showModal('checkoutModal');
    }

    updateOrderSummary() {
        const summary = document.getElementById('orderSummary');
        if (!summary) return;
        
        let total = 0;
        
        summary.innerHTML = '<h4>Order Summary</h4>';
        
        this.cart.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.innerHTML = `
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <span>${this.getTranslatedText(item, 'name')} x${item.quantity}</span>
                    <span>₹${item.price * item.quantity}</span>
                </div>
            `;
            summary.appendChild(itemElement);
            total += item.price * item.quantity;
        });
        
        const totalElement = document.createElement('div');
        totalElement.innerHTML = `
            <div style="border-top: 1px solid #ddd; padding-top: 8px; margin-top: 8px;">
                <strong>Total: ₹${total}</strong>
            </div>
        `;
        summary.appendChild(totalElement);
    }

    selectPaymentMethod(method, element) {
        document.querySelectorAll('.payment-option').forEach(option => {
            option.classList.remove('selected');
        });
        element.classList.add('selected');
        this.selectedPaymentMethod = method;
    }

    placeOrder() {
        if (!this.selectedPaymentMethod) {
            this.showToast('Please select a payment method', 'warning');
            return;
        }
        
        this.showSpinner();
        
        setTimeout(() => {
            this.hideSpinner();
            this.cart = [];
            this.updateCartDisplay();
            this.hideModal('checkoutModal');
            this.showToast('Order placed successfully! You will receive tracking information soon.', 'success');
        }, 2000);
    }

    // Search functionality
    performSearch() {
        const searchInput = document.getElementById('searchInput');
        if (!searchInput) return;
        
        const query = searchInput.value.toLowerCase().trim();
        if (!query) return;
        
        const products = document.querySelectorAll('.product-card');
        let found = false;
        
        products.forEach(product => {
            const title = product.querySelector('.product-title').textContent.toLowerCase();
            const farmer = product.querySelector('.product-farmer').textContent.toLowerCase();
            
            if (title.includes(query) || farmer.includes(query)) {
                product.classList.remove('hidden');
                found = true;
            } else {
                product.classList.add('hidden');
            }
        });

        if (found) {
            document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
        } else {
            this.showToast('No products found for your search', 'info');
        }
    }

    filterByCategory(categoryId) {
        const categoryFilter = document.getElementById('categoryFilter');
        if (categoryFilter) {
            categoryFilter.value = categoryId;
        }
        this.filterProducts();
        document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
    }

    filterProducts() {
        const categoryFilter = document.getElementById('categoryFilter');
        if (!categoryFilter) return;
        
        const categoryId = parseInt(categoryFilter.value);
        const products = document.querySelectorAll('.product-card');
        
        products.forEach(product => {
            const productCategoryId = parseInt(product.dataset.category);
            if (!categoryId || productCategoryId === categoryId) {
                product.classList.remove('hidden');
            } else {
                product.classList.add('hidden');
            }
        });
    }

    sortProducts() {
        const sortFilter = document.getElementById('sortFilter');
        const grid = document.getElementById('productsGrid');
        
        if (!sortFilter || !grid) return;
        
        const sortBy = sortFilter.value;
        const products = Array.from(grid.children);
        
        products.sort((a, b) => {
            const aIndex = Array.from(grid.children).indexOf(a);
            const bIndex = Array.from(grid.children).indexOf(b);
            const aProduct = this.data.products[aIndex];
            const bProduct = this.data.products[bIndex];
            
            switch (sortBy) {
                case 'rating':
                    return bProduct.rating - aProduct.rating;
                case 'price_low':
                    return aProduct.price - bProduct.price;
                case 'price_high':
                    return bProduct.price - aProduct.price;
                default:
                    return 0;
            }
        });
        
        grid.innerHTML = '';
        products.forEach(product => grid.appendChild(product));
    }

    // Location and farmers
    findNearbyFarmers() {
        this.showToast('Finding farmers near your location...', 'info');
        document.getElementById('farmers').scrollIntoView({ behavior: 'smooth' });
    }

    showAllFarmers() {
        this.showToast('Showing all farmers in Tamil Nadu', 'info');
    }

    showFarmerDetails(farmer) {
        this.showToast(`Contact ${this.getTranslatedText(farmer, 'name')}: ${farmer.phone}`, 'info');
    }

    contactStorageOwner(contact) {
        this.showToast(`Contact storage owner: ${contact}`, 'info');
    }

    // Authentication
    handleLogin() {
        this.showSpinner();
        setTimeout(() => {
            this.hideSpinner();
            this.hideModal('loginModal');
            this.showToast('Login successful!', 'success');
            this.currentUser = { name: 'User', type: 'customer' };
        }, 1500);
    }

    handleRegister() {
        this.showSpinner();
        setTimeout(() => {
            this.hideSpinner();
            this.hideModal('registerModal');
            this.showToast('Registration successful!', 'success');
            this.currentUser = { name: 'New User', type: 'customer' };
        }, 1500);
    }

    // Voice Recognition
    initVoiceRecognition() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.recognition = new SpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = this.currentLanguage === 'ta' ? 'ta-IN' : 'en-US';
            
            this.recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                this.handleVoiceCommand(transcript);
            };
            
            this.recognition.onerror = () => {
                this.showToast('Voice recognition error', 'error');
                this.stopVoiceRecognition();
            };
            
            this.recognition.onend = () => {
                this.stopVoiceRecognition();
            };
        }
    }

    toggleVoiceRecognition() {
        if (this.isVoiceActive) {
            this.stopVoiceRecognition();
        } else {
            this.startVoiceRecognition();
        }
    }

    startVoiceRecognition() {
        if (this.recognition) {
            this.recognition.lang = this.currentLanguage === 'ta' ? 'ta-IN' : 'en-US';
            this.recognition.start();
            this.isVoiceActive = true;
            const voiceBtn = document.getElementById('voiceBtn');
            if (voiceBtn) {
                voiceBtn.classList.add('active');
            }
            this.showToast('Voice assistant listening...', 'info');
        } else {
            this.showToast('Voice recognition not supported in this browser', 'warning');
        }
    }

    stopVoiceRecognition() {
        if (this.recognition) {
            this.recognition.stop();
        }
        this.isVoiceActive = false;
        const voiceBtn = document.getElementById('voiceBtn');
        if (voiceBtn) {
            voiceBtn.classList.remove('active');
        }
    }

    handleVoiceCommand(command) {
        const lowerCommand = command.toLowerCase();
        
        if (lowerCommand.includes('search') || lowerCommand.includes('find')) {
            const searchTerm = lowerCommand.replace(/search|find/g, '').trim();
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.value = searchTerm;
                this.performSearch();
            }
        } else if (lowerCommand.includes('cart') || lowerCommand.includes('basket')) {
            this.toggleCart();
        } else if (lowerCommand.includes('weather')) {
            document.getElementById('weather').scrollIntoView({ behavior: 'smooth' });
        } else if (lowerCommand.includes('farmer')) {
            document.getElementById('farmers').scrollIntoView({ behavior: 'smooth' });
        } else {
            this.addChatMessage('user', command);
            this.handleChatResponse(command);
        }
    }

    // Chatbot functionality
    initChatbot() {
        this.addChatMessage('bot', this.translate('welcome_message'));
    }

    toggleChatbot() {
        const body = document.getElementById('chatbotBody');
        const toggle = document.getElementById('chatbotToggle');
        
        if (!body || !toggle) return;
        
        this.chatbotExpanded = !this.chatbotExpanded;
        
        if (this.chatbotExpanded) {
            body.classList.remove('collapsed');
            toggle.classList.remove('rotated');
        } else {
            body.classList.add('collapsed');
            toggle.classList.add('rotated');
        }
    }

    sendChatMessage() {
        const input = document.getElementById('chatInput');
        if (!input) return;
        
        const message = input.value.trim();
        
        if (message) {
            this.addChatMessage('user', message);
            input.value = '';
            
            setTimeout(() => {
                this.handleChatResponse(message);
            }, 1000);
        }
    }

    addChatMessage(sender, message) {
        const messages = document.getElementById('chatMessages');
        if (!messages) return;
        
        const messageElement = document.createElement('div');
        messageElement.className = `chat-message ${sender}`;
        messageElement.textContent = message;
        messages.appendChild(messageElement);
        messages.scrollTop = messages.scrollHeight;
    }

    handleChatResponse(userMessage) {
        const lowerMessage = userMessage.toLowerCase();
        let response = this.currentLanguage === 'ta' ? 
            'நான் உங்களுக்கு உதவ இங்கே இருக்கிறேன்! பொருட்கள், விவசாயிகள், கொடுப்பனவுகள் அல்லது வானிலை பற்றி கேட்கலாம்.' :
            'I\'m here to help! You can ask me about products, farmers, payments, or weather.';
        
        // Find matching response
        for (const chatResponse of this.data.chat_responses) {
            if (lowerMessage.includes(chatResponse.trigger)) {
                response = this.currentLanguage === 'ta' ? chatResponse.response_ta : chatResponse.response;
                break;
            }
        }
        
        // Additional context-aware responses
        if (lowerMessage.includes('tamil') || lowerMessage.includes('language')) {
            response = this.currentLanguage === 'ta' ? 
                'நான் தமிழில் பேச முடியும்! எதை பற்றி பேச விரும்புகிறீர்கள்?' : 
                'I can help you in Tamil! What would you like to know?';
        } else if (lowerMessage.includes('weather')) {
            response = this.currentLanguage === 'ta' ?
                'வானிலை தகவலை பார்க்க வானிலை பிரிவுக்கு செல்லுங்கள்' :
                'Check the weather section for current conditions and forecasts.';
        } else if (lowerMessage.includes('price') || lowerMessage.includes('cost')) {
            response = this.currentLanguage === 'ta' ?
                'எங்கள் விலைகள் சந்தை விலையை விட குறைவு. நேரடி விவசாயி விலைகள்!' :
                'Our prices are below market rates. Direct farmer pricing!';
        }
        
        this.addChatMessage('bot', response);
    }

    startChatVoiceInput() {
        if (this.recognition) {
            this.recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                const chatInput = document.getElementById('chatInput');
                if (chatInput) {
                    chatInput.value = transcript;
                    this.sendChatMessage();
                }
            };
            this.startVoiceRecognition();
        }
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new FarmDirectApp();
});